# Nidhi Numerologist — interview task

Full-stack website with four pages:

- `index.html` — Home page
- `login.html` — Login page
- `register.html` — Create account page
- `dashboard.html` — Protected signed-in account page

## Run locally

This app needs Node.js 18 or newer.

```bash
npm start
```

Then open `http://localhost:3000`. The backend supports registration, password hashing, login, session cookies and logout. User data is stored locally in `data/users.json`; that file is intentionally ignored by Git.

## Deploy

GitHub Pages cannot run this backend. Deploy this repository as a Node.js web service on Render or Railway, using the start command `npm start`.

### Enable Google sign-in on Render

1. In [Google Cloud Console](https://console.cloud.google.com/), create/select a project, configure the OAuth consent screen, then create an **OAuth client ID** of type **Web application**.
2. Add this exact Authorized redirect URI to that Google client:

   ```text
   https://nidhi-numerologist.onrender.com/auth/google/callback
   ```

3. In the Render service's **Environment** settings, add these variables from that Google client:

   ```text
   GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
   GOOGLE_CLIENT_SECRET=your-client-secret
   GOOGLE_CALLBACK_URL=https://nidhi-numerologist.onrender.com/auth/google/callback
   NODE_ENV=production
   ```

4. Save the variables and redeploy. The **Continue with Google** button will then open Google's account chooser and return the user to the dashboard. Do not place the client secret in a frontend file or commit it to Git.

For local testing, set `GOOGLE_CALLBACK_URL=http://localhost:3000/auth/google/callback` and add that URI to the same Google OAuth client.

Branding, layout and code are newly created for **Nidhi Numerologist**.
